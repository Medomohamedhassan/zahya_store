import 'package:active_ecommerce_cms_demo_app/my_theme.dart';
import 'package:flutter/material.dart';

class MyStyle {
  static final appBarStyle = TextStyle(
      fontSize: 16, fontWeight: FontWeight.bold, color: MyTheme.dark_font_grey);
}
