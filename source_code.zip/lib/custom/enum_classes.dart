
enum PaymentFor {
  Order,
  WalletRecharge,
  PackagePay,
  ManualPayment,
  OrderRePayment
}
